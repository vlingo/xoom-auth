import Vue from "vue"

export const NOTIFICATION = "notifications"
export const CONNECTIONERROR = "connectionError"

export const EventBus = new Vue();