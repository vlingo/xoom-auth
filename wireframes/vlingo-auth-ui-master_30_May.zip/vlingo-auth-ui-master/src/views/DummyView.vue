<template>
    <v-container>This is a dummy view</v-container>
</template>

<script>
    export default {
        name: "dummy-view"
    }
</script>

<style scoped>

</style>